create view findteachermange as
select `onlinesystem`.`usedinfo`.`info_id`         AS `info_id`,
       `onlinesystem`.`usedinfo`.`user_id`         AS `user_id`,
       `onlinesystem`.`usedinfo`.`start_exam_time` AS `start_exam_time`,
       `onlinesystem`.`usedinfo`.`test_time`       AS `test_time`,
       `onlinesystem`.`usedinfo`.`exam_name`       AS `exam_name`,
       `onlinesystem`.`usedinfo`.`question_num`    AS `question_num`,
       `onlinesystem`.`usedinfo`.`start_id`        AS `start_id`,
       `onlinesystem`.`userinfo`.`class_id`        AS `class_id`,
       `onlinesystem`.`unitinfo`.`mange_teacher`   AS `mange_teacher`,
       `onlinesystem`.`usedinfo`.`grade`           AS `grade`,
       `onlinesystem`.`usedinfo`.`exam_id`         AS `exam_id`
from ((`onlinesystem`.`usedinfo` join `onlinesystem`.`userinfo` on ((`onlinesystem`.`usedinfo`.`user_id` =
                                                                     `onlinesystem`.`userinfo`.`user_id`)))
         join `onlinesystem`.`unitinfo`
              on ((`onlinesystem`.`userinfo`.`class_id` = `onlinesystem`.`unitinfo`.`class_id`)));

