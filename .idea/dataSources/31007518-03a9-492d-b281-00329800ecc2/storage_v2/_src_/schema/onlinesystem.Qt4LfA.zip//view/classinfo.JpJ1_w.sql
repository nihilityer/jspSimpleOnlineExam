create definer = root@localhost view classinfo as
select `onlinesystem`.`userinfo`.`user_id` AS `user_id`, `onlinesystem`.`userinfo`.`class_id` AS `class_id`
from (`onlinesystem`.`userinfo`
         join `onlinesystem`.`unitinfo`
              on ((`onlinesystem`.`userinfo`.`class_id` = `onlinesystem`.`unitinfo`.`class_id`)));

