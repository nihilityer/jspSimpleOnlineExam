create definer = root@localhost view findexaminfo as
select `onlinesystem`.`classinfo`.`user_id`   AS `user_id`,
       `onlinesystem`.`classinfo`.`class_id`  AS `class_id`,
       `onlinesystem`.`examclass`.`exam_id`   AS `exam_id`,
       `onlinesystem`.`examinfo`.`exam_name`  AS `exam_name`,
       `onlinesystem`.`examinfo`.`start_time` AS `start_time`,
       `onlinesystem`.`examinfo`.`end_time`   AS `end_time`,
       `onlinesystem`.`examinfo`.`user_time`  AS `user_time`,
       `onlinesystem`.`examinfo`.`t_score`    AS `t_score`,
       `onlinesystem`.`examinfo`.`num_q`      AS `num_q`,
       `onlinesystem`.`examinfo`.`start_id`   AS `start_id`
from ((`onlinesystem`.`classinfo` join `onlinesystem`.`examclass`)
         join `onlinesystem`.`examinfo`)
where ((`onlinesystem`.`classinfo`.`class_id` = `onlinesystem`.`examclass`.`class_id`) or
       (`onlinesystem`.`examinfo`.`create_user` = `onlinesystem`.`classinfo`.`user_id`));

